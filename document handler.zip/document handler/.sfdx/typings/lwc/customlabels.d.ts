declare module "@salesforce/label/c.Add_Review" {
    var Add_Review: string;
    export default Add_Review;
}
declare module "@salesforce/label/c.Details" {
    var Details: string;
    export default Details;
}
declare module "@salesforce/label/c.Full_Details" {
    var Full_Details: string;
    export default Full_Details;
}
declare module "@salesforce/label/c.LWC_Action" {
    var LWC_Action: string;
    export default LWC_Action;
}
declare module "@salesforce/label/c.LWC_Close_Button" {
    var LWC_Close_Button: string;
    export default LWC_Close_Button;
}
declare module "@salesforce/label/c.LWC_Modal_Name" {
    var LWC_Modal_Name: string;
    export default LWC_Modal_Name;
}
declare module "@salesforce/label/c.LWC_No_Deffered_Docment" {
    var LWC_No_Deffered_Docment: string;
    export default LWC_No_Deffered_Docment;
}
declare module "@salesforce/label/c.LWC_PENDING_DOCUMENTS_WARNING" {
    var LWC_PENDING_DOCUMENTS_WARNING: string;
    export default LWC_PENDING_DOCUMENTS_WARNING;
}
declare module "@salesforce/label/c.LWC_Submit_Button" {
    var LWC_Submit_Button: string;
    export default LWC_Submit_Button;
}
declare module "@salesforce/label/c.LWC_Upload_Document_Modal_Name" {
    var LWC_Upload_Document_Modal_Name: string;
    export default LWC_Upload_Document_Modal_Name;
}
declare module "@salesforce/label/c.LWC_Upload_File_Modal_Name" {
    var LWC_Upload_File_Modal_Name: string;
    export default LWC_Upload_File_Modal_Name;
}
declare module "@salesforce/label/c.Please_select_a_boat" {
    var Please_select_a_boat: string;
    export default Please_select_a_boat;
}
declare module "@salesforce/label/c.Reviews" {
    var Reviews: string;
    export default Reviews;
}